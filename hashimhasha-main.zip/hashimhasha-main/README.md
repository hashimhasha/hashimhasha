unité de chrage électrique (Coulomb EC)
intensité du courant (i= q/eta t) q=i.eta t ( eta t en second (s)
Loi des noeuds : la somme des courants entrants est égal a la somme des courants sortants 
loi des mailles: la somme algebrique des tensions rencontrés est égal a 0
Puissance instantanée : P=U.I
Puissance Moyenne= P=U.I/ W=P.eta T  ( 1kwh = 3.6.10°6 J)
bilan puissance= Pa=Pu+Pp
LE rendement = Pu/Pa 
relation tension courant: U=R.I
Puissance dissipé : P=U.I= R.I.I= R.I°2


